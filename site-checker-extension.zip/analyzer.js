// Lógica da extensão: olha só o texto do endereço e dá uma nota de segurança.

function interpretarURL(urlString) {
  try {
    return new URL(urlString);
  } catch (e) {
    return null;
  }
}

function ehEnderecoIP(hostname) {
  const ipv4 = /^(\d{1,3}\.){3}\d{1,3}$/;
  const ipv6 = /^\[?[0-9a-fA-F:]+\]?$/;
  return ipv4.test(hostname) || (hostname.includes(":") && ipv6.test(hostname));
}

function contarSubdominios(hostname) {
  const total = hostname.split(".").length;
  const base = extrairDominioRaiz(hostname).split(".").length;
  return Math.max(0, total - base);
}

function temCaracteresEstranhos(hostname) {
  return hostname.includes("xn--") || /[^\x00-\x7F]/.test(hostname);
}

// No Brasil os sites terminam em .com.br, então o nome principal tem 3 partes
// (itau.com.br) e não 2. Por isso existe essa lista de terminações compostas.
const SUFIXOS_COMPOSTOS = [
  "com.br", "org.br", "net.br", "gov.br", "edu.br", "mil.br",
  "co.uk", "org.uk", "com.au", "com.ar", "com.pt"
];

function extrairDominioRaiz(hostname) {
  const partes = hostname.split(".");
  const ultimos = partes.slice(-2).join(".");
  const tamanho = SUFIXOS_COMPOSTOS.includes(ultimos) ? 3 : 2;
  if (partes.length <= tamanho) return hostname;
  return partes.slice(-tamanho).join(".");
}

function trocarLetrasParecidas(str) {
  return str
    .replace(/0/g, "o")
    .replace(/1/g, "l")
    .replace(/3/g, "e")
    .replace(/4/g, "a")
    .replace(/5/g, "s")
    .replace(/8/g, "b")
    .replace(/rn/g, "m")
    .replace(/vv/g, "w");
}

function diferencaEntreTextos(a, b) {
  const linhas = a.length + 1;
  const colunas = b.length + 1;
  const custo = [];
  for (let i = 0; i < linhas; i++) {
    custo.push([]);
    for (let j = 0; j < colunas; j++) {
      custo[i].push(0);
    }
  }
  for (let i = 0; i < linhas; i++) custo[i][0] = i;
  for (let j = 0; j < colunas; j++) custo[0][j] = j;
  for (let i = 1; i < linhas; i++) {
    for (let j = 1; j < colunas; j++) {
      const substituicao = a[i - 1] === b[j - 1] ? 0 : 1;
      custo[i][j] = Math.min(
        custo[i - 1][j] + 1,
        custo[i][j - 1] + 1,
        custo[i - 1][j - 1] + substituicao
      );
    }
  }
  return custo[a.length][b.length];
}

/*
  Imitação de marca

  Golpistas registram sites parecidos com os de marcas famosas, como g00gle.com.
  Primeiro troco números e letras parecidas (0 vira o, 1 vira l) e depois conto
  quantas letras são diferentes da marca. Se a diferença for pequena e o site
  não for o oficial, é considerado imitação. Marcas com nome muito curto ficam
  de fora, porque davam muito alarme falso.
*/
function acharImitacaoDeMarca(hostname, listas) {
  const marcas = listas.MARCAS_IMITADAS || [];
  if (!marcas.length) return null;
  const raiz = extrairDominioRaiz(hostname);
  if (ehDominioConfiavel(hostname, listas)) return null;
  if ((listas.EXCECOES_IMITACAO || []).includes(raiz)) return null;

  const raizSimplificada = trocarLetrasParecidas(raiz);
  for (const marca of marcas) {
    if (raiz === marca) continue;
    const nomeMarca = marca.split(".")[0];
    if (nomeMarca.length <= 4) continue;
    const limite = nomeMarca.length <= 6 ? 1 : 2;
    const distancia = diferencaEntreTextos(raizSimplificada, marca);
    if (distancia <= limite) return marca;
  }
  return null;
}

function pareceNomeAleatorio(hostname) {
  const raiz = extrairDominioRaiz(hostname);
  const label = raiz.split(".")[0];
  if (label.length < 10) return false;
  const vogais = (label.match(/[aeiou]/gi) || []).length;
  const digitos = (label.match(/[0-9]/g) || []).length;
  const proporcaoVogais = vogais / label.length;
  const proporcaoDigitos = digitos / label.length;
  return proporcaoVogais < 0.2 || proporcaoDigitos > 0.35;
}

function ehDominioConfiavel(hostname, listas) {
  const raiz = extrairDominioRaiz(hostname);

  for (let i = 0; i < listas.DOMINIOS_CONFIAVEIS.length; i++) {
    const d = listas.DOMINIOS_CONFIAVEIS[i];
    if (hostname === d || hostname.endsWith("." + d) || raiz === d) {
      return true;
    }
  }
  for (let i = 0; i < listas.SUFIXOS_CONFIAVEIS.length; i++) {
    if (hostname.endsWith(listas.SUFIXOS_CONFIAVEIS[i])) {
      return true;
    }
  }
  return false;
}

function temPalavraDeGolpe(hostname, listas) {
  for (let i = 0; i < listas.PALAVRAS_DE_GOLPE.length; i++) {
    if (hostname.includes(listas.PALAVRAS_DE_GOLPE[i])) {
      return true;
    }
  }
  return false;
}

/*
  Como a nota é calculada

  A nota começa em 50. Cada regra que o site cumpre soma ou tira pontos (por
  exemplo: sem HTTPS tira, site conhecido soma) e o motivo fica guardado para
  aparecer no popup. No fim a nota fica entre 0 e 100 e vira um nível:
  seguro (75 ou mais), atenção (de 45 a 74) ou risco (abaixo de 45).
*/
function analisarURL(urlString, listas) {
  const resultados = [];
  const url = interpretarURL(urlString);

  if (!url) {
    return {
      pontuacao: 0,
      nivel: "desconhecido",
      resultados: [{ pontos: 0, motivo: "Não foi possível entender este endereço.", tipo: "info" }]
    };
  }

  const hostname = url.hostname.toLowerCase();
  let pontuacao = 50;

  if (["chrome:", "edge:", "brave:", "about:", "chrome-extension:", "file:"].includes(url.protocol)) {
    return {
      pontuacao: 100,
      nivel: "seguro",
      hostname,
      resultados: [{ pontos: 0, motivo: "Esta é uma página interna do navegador ou um arquivo local.", tipo: "info" }]
    };
  }

  if (["javascript:", "data:", "vbscript:"].includes(url.protocol)) {
    return {
      pontuacao: 0,
      nivel: "risco",
      hostname: hostname || "(sem domínio)",
      resultados: [{ pontos: -100, motivo: "Este link não é um endereço de site normal e pode rodar código dentro da página, o que é comum em golpes.", tipo: "negativo" }]
    };
  }

  if (url.protocol === "https:") {
    pontuacao += 15;
    resultados.push({ pontos: 15, motivo: "A conexão é protegida (HTTPS).", tipo: "positivo" });
  } else {
    pontuacao -= 30;
    resultados.push({ pontos: -30, motivo: "O site NÃO usa HTTPS, então o que você digitar pode ser visto por outras pessoas.", tipo: "negativo" });
  }

  if (ehDominioConfiavel(hostname, listas)) {
    pontuacao += 30;
    resultados.push({ pontos: 30, motivo: "Este site está na nossa lista de sites conhecidos e confiáveis.", tipo: "positivo" });
  }

  if (ehEnderecoIP(hostname)) {
    pontuacao -= 25;
    resultados.push({ pontos: -25, motivo: "O site usa só números (endereço IP) em vez de um nome, o que é comum em golpes.", tipo: "negativo" });
  }

  const numSubdominios = contarSubdominios(hostname);
  if (numSubdominios >= 3) {
    pontuacao -= 15;
    resultados.push({ pontos: -15, motivo: `O endereço tem muitas partes antes do nome principal (${numSubdominios}), o que pode esconder o site de verdade.`, tipo: "negativo" });
  }

  if (temCaracteresEstranhos(hostname)) {
    pontuacao -= 25;
    resultados.push({ pontos: -25, motivo: "O endereço tem caracteres estranhos que podem imitar as letras de uma marca conhecida.", tipo: "negativo" });
  }

  const terminacao = hostname.split(".").pop();
  if (listas.TERMINACOES_SUSPEITAS.includes(terminacao)) {
    pontuacao -= 15;
    resultados.push({ pontos: -15, motivo: `A extensão ".${terminacao}" é frequentemente associada a spam ou phishing.`, tipo: "negativo" });
  }

  if (listas.ENCURTADORES.includes(hostname)) {
    pontuacao -= 10;
    resultados.push({ pontos: -10, motivo: "Este é um link encurtado, então não dá para ver para onde ele leva.", tipo: "negativo" });
  }

  const temHifenComPalavraSuspeita = hostname.includes("-") && temPalavraDeGolpe(hostname, listas);
  if (temHifenComPalavraSuspeita) {
    pontuacao -= 25;
    resultados.push({ pontos: -25, motivo: "O nome mistura hífen com palavras como 'login', 'verify' ou 'secure', o que é comum em phishing.", tipo: "negativo" });
  }

  if (url.port && !["80", "443", ""].includes(url.port)) {
    pontuacao -= 5;
    resultados.push({ pontos: -5, motivo: `O site usa um número de porta fora do comum (${url.port}).`, tipo: "info" });
  }

  const marcaImitada = acharImitacaoDeMarca(hostname, listas);
  if (marcaImitada) {
    pontuacao -= 35;
    resultados.push({ pontos: -35, motivo: `O domínio é muito parecido com "${marcaImitada}", mas não é o domínio oficial - forte indício de phishing por imitação de marca.`, tipo: "negativo" });
  }

  if (url.username) {
    pontuacao -= 30;
    resultados.push({ pontos: -30, motivo: "O link tem um nome de usuário antes do endereço real (usuario@site.com), um truque para disfarçar para onde ele leva.", tipo: "negativo" });
  }

  if (pareceNomeAleatorio(hostname)) {
    pontuacao -= 15;
    resultados.push({ pontos: -15, motivo: "O nome do site parece aleatório (poucas vogais ou muitos números), o que é comum em sites de golpe.", tipo: "negativo" });
  }

  pontuacao = Math.max(0, Math.min(100, pontuacao));

  let nivel;
  if (pontuacao >= 75) nivel = "seguro";
  else if (pontuacao >= 45) nivel = "atencao";
  else nivel = "risco";

  return { pontuacao, nivel, hostname, resultados };
}

/*
  Google Safe Browsing

  Envia o endereço para a API do Google, que responde se ele está na lista de
  sites com malware ou phishing. Só roda se a pessoa colocou a chave nas
  configurações. Se der erro de rede ou de chave, devolve erro: true e o popup
  mostra um aviso em vez de dizer que o site é seguro.
*/
async function verificarSafeBrowsing(urlString, apiKey) {
  if (!apiKey) return { verificado: false };
  try {
    const resposta = await fetch(
      `https://safebrowsing.googleapis.com/v4/threatMatches:find?key=${encodeURIComponent(apiKey)}`,
      {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          client: { clientId: "site-seguro-extensao", clientVersion: "1.1.0" },
          threatInfo: {
            threatTypes: ["MALWARE", "SOCIAL_ENGINEERING", "UNWANTED_SOFTWARE", "POTENTIALLY_HARMFUL_APPLICATION"],
            platformTypes: ["ANY_PLATFORM"],
            threatEntryTypes: ["URL"],
            threatEntries: [{ url: urlString }]
          }
        })
      }
    );

    if (!resposta.ok) {
      return { verificado: false, erro: true };
    }

    const dados = await resposta.json();
    const ameacas = dados.matches || [];
    const tipos = [];
    for (let i = 0; i < ameacas.length; i++) {
      tipos.push(ameacas[i].threatType);
    }
    return {
      verificado: true,
      malicioso: ameacas.length > 0,
      tipos: tipos
    };
  } catch (e) {
    return { verificado: false, erro: true };
  }
}

if (typeof module !== "undefined") {
  module.exports = { analisarURL, verificarSafeBrowsing };
}

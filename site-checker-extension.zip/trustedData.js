const DOMINIOS_CONFIAVEIS = [
  "wikipedia.org",
  "wikimedia.org",
  "wiktionary.org",
  "britannica.com",
  "gov.br",
  "google.com",
  "microsoft.com",
  "apple.com",
  "mozilla.org",
  "github.com",
  "stackoverflow.com",
  "who.int",
  "un.org",
  "nasa.gov",
  "nih.gov",
  "bbc.com",
  "reuters.com"
];

const SUFIXOS_CONFIAVEIS = [
  ".gov",
  ".gov.br",
  ".edu",
  ".edu.br",
  ".mil",
  ".int"
];

const TERMINACOES_SUSPEITAS = [
  "zip", "review", "country", "kim", "cricket", "science", "work",
  "party", "gq", "cf", "tk", "ml", "ga", "top", "xyz", "click", "link",
  "loan", "download", "racing", "win"
];

const ENCURTADORES = [
  "bit.ly", "tinyurl.com", "t.co", "goo.gl", "ow.ly", "is.gd",
  "buff.ly", "adf.ly", "cutt.ly", "shorte.st", "rebrand.ly", "s.id"
];

const PALAVRAS_DE_GOLPE = [
  "login", "verify", "secure", "account", "update", "confirm",
  "banco", "senha", "seguranca", "verificar", "atualizar", "suporte"
];

const MARCAS_IMITADAS = [
  "google.com",
  "facebook.com",
  "instagram.com",
  "whatsapp.com",
  "paypal.com",
  "apple.com",
  "microsoft.com",
  "amazon.com",
  "netflix.com",
  "outlook.com",
  "gmail.com",
  "itau.com.br",
  "bradesco.com.br",
  "caixa.gov.br",
  "nubank.com.br",
  "mercadolivre.com.br",
  "santander.com.br",
  "picpay.com",
  "linkedin.com",
  "twitter.com",
  "tiktok.com"
];

const EXCECOES_IMITACAO = [
  "mail.com",
  "email.com"
];

if (typeof module !== "undefined") {
  module.exports = {
    DOMINIOS_CONFIAVEIS,
    SUFIXOS_CONFIAVEIS,
    TERMINACOES_SUSPEITAS,
    ENCURTADORES,
    PALAVRAS_DE_GOLPE,
    MARCAS_IMITADAS,
    EXCECOES_IMITACAO
  };
}

// Controla a janelinha que abre ao clicar no ícone da extensão.

const CIRCUNFERENCIA = 2 * Math.PI * 52;

function corPorNivel(nivel) {
  if (nivel === "seguro") return "#4caf50";
  if (nivel === "atencao") return "#ffb020";
  return "#ff5252";
}

function textoPorNivel(nivel) {
  if (nivel === "seguro") return "✅ Parece seguro";
  if (nivel === "atencao") return "⚠️ Atenção necessária";
  return "🚫 Sinais de risco";
}

function renderizar(resultadoAnalise) {
  const pontuacao = resultadoAnalise.pontuacao;
  const nivel = resultadoAnalise.nivel;
  const hostname = resultadoAnalise.hostname;
  const resultados = resultadoAnalise.resultados;

  document.getElementById("url-display").textContent = hostname || "URL desconhecida";

  const ringFill = document.getElementById("ring-fill");
  const offset = CIRCUNFERENCIA - (pontuacao / 100) * CIRCUNFERENCIA;
  ringFill.style.strokeDasharray = CIRCUNFERENCIA;
  ringFill.style.strokeDashoffset = offset;
  ringFill.style.stroke = corPorNivel(nivel);

  document.getElementById("score-number").textContent = pontuacao;

  const badge = document.getElementById("badge");
  badge.textContent = textoPorNivel(nivel);
  badge.className = "badge " + nivel;

  const detailsEl = document.getElementById("details");
  detailsEl.innerHTML = "";
  for (let i = 0; i < resultados.length; i++) {
    const r = resultados[i];
    const div = document.createElement("div");
    div.className = "detail-item " + r.tipo;

    let prefixo = "ℹ ";
    if (r.tipo === "positivo") prefixo = "✓ ";
    if (r.tipo === "negativo") prefixo = "✗ ";

    div.textContent = prefixo + r.motivo;
    detailsEl.appendChild(div);
  }
}

function atualizarStatusSafeBrowsing(texto, tipo) {
  const el = document.getElementById("sb-status");
  if (!el) return;
  el.textContent = texto;
  el.className = "sb-status" + (tipo ? " " + tipo : "");
}

/*
  Segunda checagem (opcional)

  Depois da análise local, se existir uma chave salva, o popup pergunta ao
  Google. Se ele achar ameaça, a nota vai para 0. Se não achar nada, a nota
  sobe 5 pontos (no máximo 100).
*/
async function verificarComSafeBrowsing(tab, resultadoLocal) {
  atualizarStatusSafeBrowsing("", "");

  if (!tab.url || !/^https?:/i.test(tab.url)) return;

  const dadosStorage = await api.storage.sync.get(["safeBrowsingApiKey"]);
  const apiKey = dadosStorage.safeBrowsingApiKey;

  if (!apiKey) {
    atualizarStatusSafeBrowsing("ℹ️ Checagem do Google desligada: falta sua chave de API (veja como pegar no site).", "");
    return;
  }

  atualizarStatusSafeBrowsing("🔍 Consultando Google Safe Browsing...", "checando");

  const resultadoSB = await verificarSafeBrowsing(tab.url, apiKey);

  if (!resultadoSB.verificado) {
    atualizarStatusSafeBrowsing(
      resultadoSB.erro ? "⚠️ Não foi possível consultar o Safe Browsing agora." : "",
      "erro"
    );
    return;
  }

  if (resultadoSB.malicioso) {
    atualizarStatusSafeBrowsing("🚨 Ameaça confirmada pelo Google Safe Browsing!", "malicioso");

    const aviso = {
      pontos: -100,
      motivo: "Este site está na lista de ameaças conhecidas do Google Safe Browsing (" + resultadoSB.tipos.join(", ") + ").",
      tipo: "negativo"
    };
    const lista = [aviso].concat(resultadoLocal.resultados);
    renderizar(montarResultado(resultadoLocal, 0, "risco", lista));
  } else {
    atualizarStatusSafeBrowsing("✓ Nenhuma ameaça conhecida (Google Safe Browsing)", "limpo");

    let pontuacaoAjustada = resultadoLocal.pontuacao + 5;
    if (pontuacaoAjustada > 100) pontuacaoAjustada = 100;

    const bom = {
      pontos: 5,
      motivo: "Nenhuma ameaça conhecida encontrada na base do Google Safe Browsing.",
      tipo: "positivo"
    };
    const lista = resultadoLocal.resultados.concat([bom]);
    renderizar(montarResultado(resultadoLocal, pontuacaoAjustada, nivelPorPontuacao(pontuacaoAjustada), lista));
  }
}

function montarResultado(base, pontuacao, nivel, lista) {
  return {
    pontuacao: pontuacao,
    nivel: nivel,
    hostname: base.hostname,
    resultados: lista
  };
}

function nivelPorPontuacao(pontuacao) {
  if (pontuacao >= 75) return "seguro";
  if (pontuacao >= 45) return "atencao";
  return "risco";
}

async function rodarAnalise() {
  atualizarStatusSafeBrowsing("", "");
  const abas = await api.tabs.query({ active: true, currentWindow: true });
  const tab = abas[0];
  if (!tab || !tab.url) return;

  const listas = {
    DOMINIOS_CONFIAVEIS, SUFIXOS_CONFIAVEIS, TERMINACOES_SUSPEITAS, ENCURTADORES,
    PALAVRAS_DE_GOLPE, MARCAS_IMITADAS, EXCECOES_IMITACAO
  };
  const resultado = analisarURL(tab.url, listas);
  renderizar(resultado);
  verificarComSafeBrowsing(tab, resultado);
}

document.addEventListener("DOMContentLoaded", rodarAnalise);
const botaoRescan = document.getElementById("rescan");
if (botaoRescan) {
  botaoRescan.addEventListener("click", rodarAnalise);
}
